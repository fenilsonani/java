package ciepractice.String_method;

public class Simple_Strings {
    public static void main(String[] args) {
        String str="Fenil Sonani";
        String str1=new String("Fenil Sonani");
        System.out.println("Lenght Of Array "+str.length());

    }
}
