package meet;

public class BalanceException extends Exception{
    public BalanceException(String str){
        super(str);
    }
}